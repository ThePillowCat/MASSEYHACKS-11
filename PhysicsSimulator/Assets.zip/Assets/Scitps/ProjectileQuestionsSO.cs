using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;


public enum PhysicsVariable
{
    Distance,
    Time,
    InitialVelocity,
    FinalVelocity,
    Acceleration
}


[CreateAssetMenu(fileName = "NewPhysicsQuestion", menuName = "Physics/Question Template")]

public class ProjectileQuestionsSO : ScriptableObject
{
    // Start is called before the first frame update

    [TextArea(3, 10)]
    public string questionText;

    public PhysicsVariable unknown;
    public PhysicsVariable unused;

    public float minDist;
    public float maxDist;

    public float minTime;
    public float maxTime;

    public float minVelocity;
    public float maxVelocity;

    public float minAcceleration;
    public float maxAcceleration;

    public float SolveNoVf(PhysicsVariable variable, float dist, float time, float vi, float accel)
    {
        switch (variable)
        {
            case PhysicsVariable.Distance:
                return vi * time + 0.5f * accel * time * time;
            case PhysicsVariable.InitialVelocity:
                return (dist - 0.5f * accel * time * time) / time;
            case PhysicsVariable.Acceleration:
                return 2 * (dist - vi * time) / (time * time);

            default:
                return -1;
        }
    }
    public float SolveNoVi(PhysicsVariable variable, float dist, float time, float vf, float accel)
    {
        switch (variable)
        {
            case PhysicsVariable.Distance:
                return vf * time - 0.5f * accel * time * time;
            case PhysicsVariable.FinalVelocity:
                return (dist + 0.5f * accel * time * time) / time;
            case PhysicsVariable.Acceleration:
                return 2 * (dist + vf * time) / (time * time);
            default:
                return -1;
        }
    }
    public float SolveNoDist(PhysicsVariable variable, float time, float vi, float vf, float accel)
    {
        switch (variable)
        {
            case PhysicsVariable.InitialVelocity:
                return -accel * time + vf;
            case PhysicsVariable.FinalVelocity:
                return accel * time - vf;
            case PhysicsVariable.Acceleration:
                return (vf - vi)/time;
            case PhysicsVariable.Time:
                return (vf - vi) * accel;
            default:
                return -1;
        }
    }
    public float SolveNoTime(PhysicsVariable variable, float dist, float vi, float vf, float accel)
    {
        switch (variable)
        {
            case PhysicsVariable.InitialVelocity:
                return Mathf.Sqrt(vf*vf - 2 * accel * dist);
            case PhysicsVariable.FinalVelocity:
                return Mathf.Sqrt(vi * vi + 2 * accel * dist);
            case PhysicsVariable.Acceleration:
                return (vf*vf - vi * vi)/(2 * dist);
            case PhysicsVariable.Distance:
                return (vf * vf - vi * vi) / (2 * accel); ;
            default:
                return -1;
        }
    }

    public float SolveNoAccel(PhysicsVariable variable, float dist, float vi, float vf, float time)
    {
        switch (variable)
        {
            case PhysicsVariable.InitialVelocity:
                return dist/time * 2 - vf;
            case PhysicsVariable.FinalVelocity:
                return dist/time * 2 - vi; ;
            case PhysicsVariable.Time:
                return (2*dist)/(vi+vf);
            case PhysicsVariable.Distance:
                return (vi+vf)*time/2; ;
            default:
                return -1;
        }
    }

}
